﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Pause : MonoBehaviour
{
	public static bool isGamePaused = false;
    public AudioSource track;

	[SerializeField] GameObject PauseM;

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape)){
        	if(isGamePaused){
        		ResumeGame();
        	}else{
        		PauseGame();
        	}
        }
    } 

    public void ResumeGame(){
        PauseM.SetActive(false);
        Time.timeScale=1f;
        isGamePaused = false;
       // track.Resume();

    }

    void PauseGame(){
        PauseM.SetActive(true);
        Time.timeScale=0f;
        isGamePaused = true;
       // track.Pause();
    }

    public void LoadMenu(){
        SceneManager.LoadScene("MainMenu");
    }

    public void QuitGame(){
        Application.Quit();

        Debug.Log("Quit");
    }



}

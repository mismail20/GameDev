﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGScroller : MonoBehaviour
{
    /* public BoxCollider2D collider;

    public Rigidbody2D rb;

    private float width;

    private float scrollSpeed = -2f;





    void Start()
    {
        collider = GetComponent<BoxCollider2D>();
        rb = GetComponent<Rigidbody2D>();

        width = GetComponent<Collider>().size.x;
        GetComponent<Collider>().enabled = false;

        rb.velocity = new Vector2(scrollSpeed, 0);
    }

    // Update is called once per frame
    void Update()
    {
      if (transform.position.x < -width) // Resets screen position when if at end of screen
      {
        Vector2 resetPosition = new Vector2(width * 2f, 0);
        transform.position = (Vector2)transform.position + resetPosition;
      }

    }
    */
}
